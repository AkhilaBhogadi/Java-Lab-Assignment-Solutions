package com.capg8;

import java.util.Queue;

public class BillerThread implements Runnable {
	private Queue sharedQ;
	private final int MAX_SIZE;

	public BillerThread(Queue sharedQ, int MAX_SIZE) {
		super();
		this.sharedQ = sharedQ;
		this.MAX_SIZE = MAX_SIZE;
	}

	@Override
	public void run() {
		while (true) {
			synchronized (sharedQ) {
				while (sharedQ.isEmpty()) {
					try {
						System.out.println("Billing completed");
						sharedQ.wait();
					} catch (Exception e) {
						System.out.println("error:" + e);
					}
				}
				System.out.println("product:" + sharedQ.remove());
			}
		}
	}
}
