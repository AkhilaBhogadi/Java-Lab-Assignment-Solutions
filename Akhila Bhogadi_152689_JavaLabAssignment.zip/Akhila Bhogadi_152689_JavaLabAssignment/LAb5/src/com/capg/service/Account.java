package com.capg.service;

public abstract class Account {

	private long accNo;
	protected double balance;
	Person per;
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getPer() {
		return per;
	}
	public void setPer(Person per) {
		this.per = per;
	}
	
	public abstract double deposit(double ammount);
	public abstract void withDraw(double ammount);
	public double getMoney() {
		return balance;
	}
}
