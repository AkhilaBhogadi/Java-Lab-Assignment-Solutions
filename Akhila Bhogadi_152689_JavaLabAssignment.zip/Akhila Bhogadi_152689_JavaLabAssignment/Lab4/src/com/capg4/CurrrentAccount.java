package com.capg4;

public class CurrrentAccount extends Account {
double overdraftlimit;
double loan;
@Override
public void withdraw(double amt) {
	overdraftlimit = balance*0.1;
	if(amt<=(balance+overdraftlimit)) {
		balance -= amt;
		loan = -(balance);
		if(loan>0) {
			balance=0;
			System.out.println("");
		}
	}
	else {
		System.out.println("overdraftlimit reached...insufficient balance");
	}
}
}
