package com.capg9;

import java.io.FileInputStream;

import java.io.FileNotFoundException;

import java.io.FileOutputStream;

import java.io.IOException;

import java.io.ObjectInputStream;

import java.io.ObjectOutputStream;

import java.io.Serializable;

class Employee implements Serializable {
	String name;
	int id;
	float salary;
	String designation;

	public Employee(String name, int id, float salary, String designation) {
		super();
		this.name = name;
		this.id = id;
		this.salary = salary;
		this.designation = designation;
	}

	public void showDetails() {
		System.out.println("Employee ID:" + id);
		System.out.println("Employee name:" + name);
		System.out.println("Salary:" + salary);
		System.out.println("Designation:" + designation);
	}
}
