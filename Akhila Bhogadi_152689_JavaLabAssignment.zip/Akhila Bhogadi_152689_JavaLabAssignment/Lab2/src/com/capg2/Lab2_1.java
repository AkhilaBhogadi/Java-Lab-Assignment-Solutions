package com.capg2;
import java.util.Scanner;
public class Lab2_1 {

	
	 
	
	    public static void main(String args[])  throws Exception
	    {
	        String name1 = "Divya" , name2 = "Bharathi" , gender= "F";
	        int age = 20;
	        double weight = 85.5;
	       
	       // Scanner SC=new Scanner(System.in);
	       
	        //System.out.print("Enter first name: ");
	      // name1= SC.nextLine();
	        //System.out.print("Enter last name: ");
	        //name2= SC.nextLine();  
	    //  System.out.print("Enter Gender (Male/Female): ");
	       // gender=SC.next();
	 
	     //   System.out.print("Enter age: ");
	     //   age=SC.nextInt();
	 
	    //    System.out.print("Enter weight: ");
	       // weight=SC.nextFloat();
	        System.out.print("Person Details:\n "); 
	        System.out.println("______________________________\n");
	        
	        System.out.println("First Name: " + name1);
	        System.out.println("Last Name: " + name2);
	        System.out.println("Gender: " + gender);
	        System.out.println("Age: " + age);
	        System.out.println("Weight: " + weight);
	                                  
	    }
	}