package com.capg11;

public interface ILab11_1 {
public double power(double x, double y);
}
